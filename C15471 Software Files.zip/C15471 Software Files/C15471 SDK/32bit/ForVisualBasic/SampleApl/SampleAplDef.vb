﻿Imports System.Collections.Generic
Imports System.Text

Class SampleAplDef
    Public Const D_IMAGE_HEADER_SIZE As Integer = 256
    'Header size
    Public Const D_DATA_COUNT_MAX_VALUE As Integer = 1
    'Data count
    Public Const D_DATA_TRANSMIT_COUNT As Integer = 1
    'Data transmit count
    Public Const D_FREQUENCYMODE_FRAME_COUNT As Integer = 1
    'Frame count(Frequency specified mode)
    Public Const D_OTHERMODE_FRAME_COUNT As Integer = 5
    'Frame count(Capture mode continuous and trigger)
    Public Const D_EXPOSURE_TIME As Integer = 20000
    'Exposure Time(usec)
    Public Const D_CYCLE_TIME As Integer = 210000
    'Cycle time(usec)
    Public Const D_REPEAT_COUNT As Integer = 5
    'Repeat count
End Class

'-----------------------------------------------------------------------------
' enum
'-----------------------------------------------------------------------------
Enum E_CAPTUREMODE
    'Capture mode
    D_CAPTUREMODE_COUNT = &H0
    'Frequency specified meausrement mode
    D_CAPTUREMODE_CONTINUOUS = &H1
    'Continous measurement mode
    D_CAPTUREMODE_TRIGGER = &H2
    'Trigger mode
End Enum

Enum E_TRIGGERMODE
    D_TRIGGERMODE_INTERNAL = &H0
    'Internal synchronous mode
    D_TRIGGERMODE_SOFTASYNC = &H1
    'Software asynchronous mode
    D_TRIGGERMODE_SOFTSYNC = &H2
    'Software synchronous mode
    D_TRIGGERMODE_EXTASYNCEDGE = &H3
    'External asynchronous edge sense mode
    D_TRIGGERMODE_EXTASYNCLEVEL = &H4
    'External asynchronous level sense mode
    D_TRIGGERMODE_EXTSYNCEDGE = &H5
    'External synchronous edge sense mode
    D_TRIGGERMODE_EXTSYNCLEVEL = &H6
    'External synchronous level sense mode
    D_TRIGGERMODE_EXTSYNCPULSE = &H7
    'External synchronous pulse mode
End Enum

Enum E_CALIBRATIONCOEFFICIENT
    D_CALIBRATIONCOEFFICIENT_WAVELENGTH = &H0
    'Wavelength calibration coefficient
    D_CALIBRATIONCOEFFICIENT_SENSIBILITY = &H1
    'Sensibility calibration coefficient
End Enum

Enum E_GAINMODE
    D_GAINMODE_SENSOR = &H0
    'SensorGainMode
    D_GAINMODE_CIRCUIT = &H1
    'CircuitGainMode
End Enum

Enum E_SENSORGAINMODE
    D_SENSORGAINMODE_LOWGAIN = &H0
    'Low Gain
    D_SENSORGAINMODE_HIGHGAIN = &H1
    'High Gain
    D_SENSORGAINMODE_NOTHING = &HFF
    'Nothing
End Enum
