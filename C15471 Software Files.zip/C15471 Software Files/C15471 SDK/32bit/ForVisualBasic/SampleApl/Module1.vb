﻿' ======================================================================================
'
'   Copyright (c) 2019 Hamamatsu Photonics K.K.
'
'   Project         : C15471 Sample Application(VB)
'
'   .NET Framework  : .NET Framework 3.5
'
'=======================================================================================
Imports System.Threading
Imports System.Diagnostics
Imports WRRUSB2_DLL

''' <summary>
''' Program class
''' </summary>
Class Program
    ''' <summary>
    ''' DeviceID
    ''' </summary>
    ''' <remarks></remarks>
    Private Shared m_lDeviceID As Long = -1

    ''' <summary>
    ''' Main
    ''' </summary>
    ''' <param name="args"></param>
    Friend Shared Sub Main(args As String())
        Dim lReturn As Long = 0
        Dim nLoopFlag As Integer = 1
        Dim cInput As Char = " "
        Dim objWrrUSB As WRRUSB2 = Nothing

        Console.WriteLine("Hamamatsu Minispectrometer sample application")

        'Create object of WRRUSB2 class
        objWrrUSB = New WRRUSB2()
        If objWrrUSB Is Nothing Then
            Return
        End If

        'Device initialize
        lReturn = InitializeDevice(objWrrUSB)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Return
        End If

        'print the menu
        PrintMenu()
        While nLoopFlag = 1
            Console.Write(">")
            cInput = Char.ToUpper(Console.ReadKey().KeyChar)
            Console.WriteLine("")

            Select Case cInput
                Case "0"c
                    PrintMenu()
                    Exit Select

                Case "1"c
                    lReturn = GetDeivceInformation(objWrrUSB)
                    Exit Select

                Case "2"c
                    lReturn = GetCalibrationValue(objWrrUSB)
                    Exit Select

                Case "3"c
                    lReturn = GetLDPower(objWrrUSB)
                    Exit Select

                Case "4"c
                    lReturn = SetLDPower(objWrrUSB)
                    Exit Select

                Case "5"c
                    lReturn = GetLDPowerEnable(objWrrUSB)
                    Exit Select

                Case "6"c
                    lReturn = SetLDPowerEnable(objWrrUSB)
                    Exit Select

                Case "7"c
                    lReturn = GetLDTemperature(objWrrUSB)
                    Exit Select

                Case "8"c
                    lReturn = GetLDBoardTemperature(objWrrUSB)
                    Exit Select

                Case "F"c
                    lReturn = StartMeasureForFrequencyMode(objWrrUSB)
                    Exit Select

                Case "G"c
                    lReturn = StartMeasureForContinuousMode(objWrrUSB)
                    Exit Select

                Case "H"c
                    lReturn = StartMeasureForTriggerMode(objWrrUSB)
                    Exit Select

                Case "Q"c
                    nLoopFlag = 0
                    Exit Select
                Case Else

                    Exit Select
            End Select
        End While

        'Device uninitialize
        lReturn = UninitializeDevice(objWrrUSB)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Return
        End If

        Return
    End Sub

    ''' <summary>
    ''' Initialize device function
    ''' </summary>
    ''' <param name="objWrrUSB">DLL</param>
    ''' <returns></returns>
    Private Shared Function InitializeDevice(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0
        Dim strNum As UShort = 0
        Dim arysDeviceList As Short() = Nothing
        Dim strType As String = ""
        Dim cStatus As Char = ControlChars.NullChar
        Dim objSpectroInfo As Usb2Struct.CSpectroInformation = Nothing

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        'Initialization
        lReturn = objWrrUSB.USB2_initialize()
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: Dll Can not be Initialized.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Device ID storage area allocation
        arysDeviceList = New Short(7) {}
        If arysDeviceList Is Nothing Then
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If
        Array.Clear(arysDeviceList, 0, arysDeviceList.Length)

        'Get connected device list
        lReturn = objWrrUSB.USB2_getModuleConnectionList(arysDeviceList, strNum)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            objWrrUSB.USB2_uninitialize()
            Console.WriteLine("Error code 0x{0:x04}: Module Connection list failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set acquired device ID
        m_lDeviceID = arysDeviceList(0)

        'Open device
        lReturn = objWrrUSB.USB2_open(m_lDeviceID)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            objWrrUSB.USB2_uninitialize()
            Console.WriteLine("Error code 0x{0:x04}: Device can not be open.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Get UnitID
        objSpectroInfo = New Usb2Struct.CSpectroInformation()
        lReturn = objWrrUSB.USB2_getSpectroInformation(m_lDeviceID, objSpectroInfo)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            objWrrUSB.USB2_close(m_lDeviceID)
            objWrrUSB.USB2_uninitialize()
            Console.WriteLine("Error code 0x{0:x04}: USB2_getSpectroInformation failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Check CooledType
        strType = objSpectroInfo.unit.Substring(0, 2)
        If strType = "D1" Then
            'Cooling stability Waiting
            Console.WriteLine("Cooling stability Waiting...")
            While True
                'Gets data showing internal status
                lReturn = objWrrUSB.USB2_GetStatusRequest(m_lDeviceID, cStatus)
                If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
                    objWrrUSB.USB2_close(m_lDeviceID)
                    objWrrUSB.USB2_uninitialize()
                    Console.Write("Error code 0x{0:x04}: USB2_GetStatusRequest failed.", lReturn)
                    Console.WriteLine("Exit by pressing the key")
                    Console.ReadKey()
                    Return lReturn
                End If

                'Cooled Status Check
                If Integer.Parse(cStatus) = 1 Then
                    Exit While
                End If

                'Error Check
                If Integer.Parse(cStatus) >= 2 Then
                    Console.WriteLine("Cooled Error Occured.")
                    'cStatus = 2  : Fan rotational speed is less than 9V
                    'cStatus = 32 : Chassis’ temperature falls outside the regulated temperature range
                    'Please check the USB2.0SpectrometerFunctionSpecifications for more information
                    Console.WriteLine("Exit by pressing the key")
                    Console.ReadKey()
                    Return lReturn
                End If
                Thread.Sleep(1000)
            End While
        End If

        Return lReturn
    End Function

    ''' <summary>
    ''' Uninitialize device function
    ''' </summary>
    ''' <param name="objWrrUSB">DLL</param>
    ''' <returns></returns>
    Private Shared Function UninitializeDevice(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        'Close device
        lReturn = objWrrUSB.USB2_close(m_lDeviceID)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: Device can not be closed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Uninitialization
        lReturn = objWrrUSB.USB2_uninitialize()
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_uninitialize failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
        End If

        Return lReturn
    End Function

    ''' <summary>
    ''' Get device information function
    ''' </summary>
    ''' <param name="objWrrUSB">DLL</param>
    ''' <returns></returns>
    Private Shared Function GetDeivceInformation(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0
        Dim objModuleInfo As Usb2Struct.CModuleInformation = Nothing
        Dim objSpecInfo As Usb2Struct.CSpectroInformation = Nothing

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        Try
            objModuleInfo = New Usb2Struct.CModuleInformation()
            objSpecInfo = New Usb2Struct.CSpectroInformation()
        Catch generatedExceptionName As OutOfMemoryException
            Debug.Assert(False)
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End Try

        lReturn = objWrrUSB.USB2_getModuleInformation(m_lDeviceID, objModuleInfo)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_getModuleInformation failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
        End If

        lReturn = objWrrUSB.USB2_getSpectroInformation(m_lDeviceID, objSpecInfo)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_getSpectroInformation failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
        End If

        Console.WriteLine("Deivce information")
        Console.WriteLine("ModelName : {0}", objModuleInfo.product)
        Console.WriteLine("SerialNo  : {0}", objModuleInfo.serial)
        Console.WriteLine("UnitID    : {0}", objSpecInfo.unit)
        Console.WriteLine("FirmVer   : {0}", objModuleInfo.firmware)

        Return lReturn
    End Function

    ''' <summary>
    ''' Get calibration value function
    ''' </summary>
    ''' <param name="objWrrUSB">DLL</param>
    ''' <returns></returns>
    Private Shared Function GetCalibrationValue(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0
        Dim arydblCalibration As Double() = Nothing

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        Try
            arydblCalibration = New Double(5) {}
        Catch generatedExceptionName As OutOfMemoryException
            Debug.Assert(False)
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End Try

        lReturn = objWrrUSB.USB2_getCalibrationCoefficient(m_lDeviceID, CLng(E_CALIBRATIONCOEFFICIENT.D_CALIBRATIONCOEFFICIENT_WAVELENGTH), arydblCalibration)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_getCalibrationCoefficient failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        Console.WriteLine("Calibration coefficients")
        Console.WriteLine("  A0 : {0:E}", arydblCalibration(0))
        Console.WriteLine("  B1 : {0:E}", arydblCalibration(1))
        Console.WriteLine("  B2 : {0:E}", arydblCalibration(2))
        Console.WriteLine("  B3 : {0:E}", arydblCalibration(3))
        Console.WriteLine("  B4 : {0:E}", arydblCalibration(4))
        Console.WriteLine("  B5 : {0:E}", arydblCalibration(5))
        Console.WriteLine("")

        Return lReturn
    End Function

    ''' <summary>
    ''' Get LD Power
    ''' </summary>
    ''' <param name="objWrrUSB">DLL</param>
    ''' <returns></returns>
    Private Shared Function GetLDPower(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0
        Dim lLDPower As Long = 0

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        lReturn = objWrrUSB.USB2_getLDPower(m_lDeviceID, lLDPower)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_getLDPower failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If
        Console.WriteLine("LD Power : 0x{0:X08}", lLDPower)
        Console.WriteLine("")

        Return lReturn
    End Function

    ''' <summary>
    ''' Set LD Power
    ''' </summary>
    ''' <param name="objWrrUSB">DLL</param>
    ''' <returns></returns>
    Private Shared Function SetLDPower(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0
        Dim lLDPower As Long = 0

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        Console.WriteLine("Input LDPower (long)")
        Console.WriteLine("LOW    : 1")
        Console.WriteLine("MIDDLE : 2")
        Console.WriteLine("HIGH   : 3")

        Try
            Console.Write("Set LD Power > ")
            Long.TryParse(Console.ReadLine(), lLDPower)
        Catch generatedExceptionName As Exception
            Debug.Assert(False)
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End Try

        lReturn = objWrrUSB.USB2_setLDPower(m_lDeviceID, lLDPower)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setLDPower failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If
        Console.WriteLine("")

        Return lReturn
    End Function

    ''' <summary>
    ''' Get LD Power enable
    ''' </summary>
    ''' <param name="objWrrUSB"></param>
    ''' <returns></returns>
    Private Shared Function GetLDPowerEnable(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0
        Dim lLDPowerEnable As Long = 0

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return Convert.ToInt64(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        lReturn = objWrrUSB.USB2_getLDPowerEnable(m_lDeviceID, lLDPowerEnable)
        If lReturn <> Convert.ToInt64(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_getLDPowerEnable failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If
        Console.WriteLine("LD Power Enable : 0x{0:x08}", lLDPowerEnable)
        Console.WriteLine("")

        Return lReturn
    End Function

    ''' <summary>
    ''' Set LD Power enable
    ''' </summary>
    ''' <param name="objWrrUSB"></param>
    ''' <returns></returns>
    Private Shared Function SetLDPowerEnable(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0
        Dim lLDPowerEnable As Long = 0

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return Convert.ToInt64(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        Try
            Console.WriteLine("Input LDPowerEnable (long)")
            Console.WriteLine("Enable  : 1")
            Console.WriteLine("Disable : Other than 1")
            Console.Write("Set LD Power Enable > ")
            Long.TryParse(Console.ReadLine(), lLDPowerEnable)
        Catch generatedExceptionName As Exception
            Debug.Assert(False)
            Return Convert.ToInt64(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End Try

        lReturn = objWrrUSB.USB2_setLDPowerEnable(m_lDeviceID, lLDPowerEnable)
        If lReturn <> Convert.ToInt64(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setLDPowerEnable failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If
        Console.WriteLine("")

        Return lReturn
    End Function

    ''' <summary>
    ''' Get LD temperature
    ''' </summary>
    ''' <param name="objWrrUSB"></param>
    ''' <returns></returns>
    Private Shared Function GetLDTemperature(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0
        Dim lLDTemp As Long = 0

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return Convert.ToInt64(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        lReturn = objWrrUSB.USB2_getLDTemp(m_lDeviceID, lLDTemp)
        If lReturn <> Convert.ToInt64(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_getLDTemp failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If
        Console.WriteLine("LDTemp : {0}[degC]", Convert.ToDouble(lLDTemp) / 100)
        Console.WriteLine("")

        Return lReturn
    End Function

    ''' <summary>
    ''' Get LD board temperature
    ''' </summary>
    ''' <param name="objWrrUSB"></param>
    ''' <returns></returns>
    Private Shared Function GetLDBoardTemperature(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0
        Dim lLDBoardTemp As Long = 0

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return Convert.ToInt64(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        lReturn = objWrrUSB.USB2_getLDBoardTemp(m_lDeviceID, lLDBoardTemp)
        If lReturn <> Convert.ToInt64(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_getLDBoardTemp failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If
        Console.WriteLine("LDBoardTemp : {0}[degC]", Convert.ToDouble(lLDBoardTemp) / 100)
        Console.WriteLine("")

        Return lReturn
    End Function

    ''' <summary>
    ''' Display manu function
    ''' </summary>
    Private Shared Sub PrintMenu()
        Console.WriteLine("--------------------------------------------------------------------------")
        Console.WriteLine("  Menu               (0) Menu")
        Console.WriteLine("  DeviceInformation  (1) Get")
        Console.WriteLine("  Calibration        (2) Get")
        Console.WriteLine("  LDPower            (3) Get            (4) Set")
        Console.WriteLine("  LDPowerEnable      (5) Get            (6) Set")
        Console.WriteLine("  LDTemperature      (7) Get")
        Console.WriteLine("  LDBoardTemp        (8) Get")
        Console.WriteLine("  Measure            (F) FrequencyMode  (G) ContinuousMode (H) TriggerMode")
        Console.WriteLine("  Quit               (Q) Quit")
        Console.WriteLine("--------------------------------------------------------------------------")
    End Sub

    ''' <summary>
    ''' Measurement start function (Frequency specified meausrement mode)
    ''' </summary>
    ''' <param name="objWrrUSB">DLL</param>
    ''' <returns></returns>
    Private Shared Function StartMeasureForFrequencyMode(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0
        Dim pixelSize As Long = 0
        Dim repeatCount As Integer = 0
        Dim captureFrameCnt As Int64 = 0
        Dim currCaptureIdx As Int64 = 0
        Dim oldIndex As Long = 0
        Dim imageDataSize As Long = 0
        Dim frameCnt As Long = SampleAplDef.D_FREQUENCYMODE_FRAME_COUNT
        Dim dataTrasmit As Long = SampleAplDef.D_DATA_TRANSMIT_COUNT
        Dim dataCount As Long = SampleAplDef.D_DATA_COUNT_MAX_VALUE
        Dim sizeX As Int64 = 0
        Dim sizeY As Int64 = 0
        Dim gainMode As Long = CLng(E_GAINMODE.D_GAINMODE_SENSOR)
        Dim sensorGainMode As Long = CLng(E_SENSORGAINMODE.D_SENSORGAINMODE_LOWGAIN)
        Dim imageData As UShort() = Nothing
        Dim imageHeader As UShort() = Nothing
        Dim time As UInt64() = Nothing

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        Console.WriteLine("Parameter setting.........")

        'Set CaptureMode 
        lReturn = objWrrUSB.USB2_setCaptureMode(m_lDeviceID, CLng(E_CAPTUREMODE.D_CAPTUREMODE_COUNT))
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setCaptureMode failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        ' Set TriggerMode
        lReturn = objWrrUSB.USB2_setTriggerMode(m_lDeviceID, CLng(E_TRIGGERMODE.D_TRIGGERMODE_INTERNAL))
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setTriggerMode failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set acquired data count
        lReturn = objWrrUSB.USB2_setDataCount(m_lDeviceID, dataCount)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setDataCount failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set data transmit count
        lReturn = objWrrUSB.USB2_setDataTransmit(m_lDeviceID, dataTrasmit)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setDataTransmit failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set exposure cycle
        lReturn = objWrrUSB.USB2_setExposureCycle(m_lDeviceID, SampleAplDef.D_CYCLE_TIME)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setExposureCycle failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set exposure time
        lReturn = objWrrUSB.USB2_setExposureTime(m_lDeviceID, SampleAplDef.D_EXPOSURE_TIME)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setExposureTime failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set gain value(Set the sensor gain mode, and set low gain or high gain)
        lReturn = objWrrUSB.USB2_setGain(m_lDeviceID, gainMode, sensorGainMode)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setGain failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Get image size
        lReturn = objWrrUSB.USB2_getImageSize(m_lDeviceID, sizeX, sizeY)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_getImageSize failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If
        pixelSize = sizeX * sizeY

        Console.WriteLine("Allocate buffer.........")

        'Buffer allocation
        lReturn = objWrrUSB.USB2_allocateBuffer(m_lDeviceID, frameCnt)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_allocateBuffer failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Capture start
        Console.WriteLine("Start Capture.............")
        lReturn = objWrrUSB.USB2_captureStart(m_lDeviceID, frameCnt)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: Data capture can not be start.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        Console.WriteLine("")
        Console.WriteLine("Image Data ")

        'Data acquisition is reapeated 5 times while determining status of capture
        Do
            'Acquire capture status
            lReturn = objWrrUSB.USB2_getCaptureStatus(m_lDeviceID, captureFrameCnt, currCaptureIdx)
            Trace.WriteLine("APLLOGC++:CaptureStatus lReturn = " & lReturn.ToString() & " captureFrameCnt = " & captureFrameCnt.ToString() & "currCaptureIdx = " & currCaptureIdx.ToString())
            If lReturn = CLng(Usb2Struct.Cusb2Err.usb2Success) Then

                'Calculate old index
                If captureFrameCnt > currCaptureIdx + 1 Then
                    oldIndex = SampleAplDef.D_OTHERMODE_FRAME_COUNT - (captureFrameCnt - (currCaptureIdx + 1))
                Else
                    oldIndex = (currCaptureIdx - captureFrameCnt) + 1
                End If

                'Allocate buffer to store header
                imageHeader = New UShort(SampleAplDef.D_IMAGE_HEADER_SIZE * captureFrameCnt - 1) {}
                If imageHeader Is Nothing Then
                    Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
                End If
                Array.Clear(imageHeader, 0, imageHeader.Length)

                'Allocate a buffer to store data
                imageDataSize = captureFrameCnt * dataTrasmit * pixelSize
                imageData = New UShort(imageDataSize - 1) {}
                If imageData Is Nothing Then
                    Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
                End If
                Array.Clear(imageData, 0, imageData.Length)

                'Allocate buffer to store time
                time = New UInt64(dataTrasmit * captureFrameCnt - 1) {}
                If time Is Nothing Then
                    Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
                End If

                'Get data from device
                lReturn = objWrrUSB.USB2_getImageHeaderData(m_lDeviceID, imageHeader, imageData, oldIndex, captureFrameCnt, time)
                Trace.WriteLine("APLLOGC++:getImageHeaderData lReturn = " & lReturn.ToString())
                If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then

                    Console.WriteLine("Error code 0x{0:x04}: USB2_getImageHeaderData failed.", lReturn)
                    Console.WriteLine("Exit by pressing the key")
                    Console.ReadKey()
                    Return lReturn
                End If

                'Display data
                DisplayData(imageData)

                Console.WriteLine("Stop Capture.........")
                'Stop capture
                lReturn = objWrrUSB.USB2_captureStop(m_lDeviceID)
                If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
                    Console.WriteLine("Error code 0x{0:x04}: USB2_captureStop failed.", lReturn)
                    Console.WriteLine("Exit by pressing the key")
                    Console.ReadKey()
                    Return lReturn
                End If

                'Release allocated buffer
                If imageData IsNot Nothing Then
                    imageData = Nothing
                End If
                If imageHeader IsNot Nothing Then
                    imageHeader = Nothing
                End If
                If time IsNot Nothing Then
                    time = Nothing
                End If

                repeatCount += 1

                If repeatCount < SampleAplDef.D_REPEAT_COUNT Then
                    'next Capture start
                    Console.WriteLine("Start Capture.............")
                    lReturn = objWrrUSB.USB2_captureStart(m_lDeviceID, frameCnt)
                    If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
                        Console.WriteLine("Error code 0x{0:x04}: Data capture can not be start.", lReturn)
                        Console.WriteLine("Exit by pressing the key")
                        Console.ReadKey()
                        Return lReturn
                    End If
                End If
            End If
            Thread.Sleep(250)
        Loop While repeatCount < SampleAplDef.D_REPEAT_COUNT

        'Stop capture
        Console.WriteLine("Stop Capture.........")
        lReturn = objWrrUSB.USB2_captureStop(m_lDeviceID)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_captureStop failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        Thread.Sleep(100)

        'Release buffer
        Console.WriteLine("Rleasing Buffer......")
        lReturn = objWrrUSB.USB2_releaseBuffer(m_lDeviceID)
        If lReturn <> CType(Usb2Struct.Cusb2Err.usb2Success, Int32) Then
            Console.Write("Error code 0x{0:x04}: USB2_releaseBuffer failed.", lReturn)
            Return lReturn
        End If

        Console.WriteLine("End of measurement")

        Return CLng(Usb2Struct.Cusb2Err.usb2Success)
    End Function

    ''' <summary>
    ''' Measurement start function (Continous measurement mode)
    ''' </summary>
    ''' <param name="objWrrUSB">DLL</param>
    ''' <returns></returns>
    Private Shared Function StartMeasureForContinuousMode(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0
        Dim pixelSize As Long = 0
        Dim repeatCount As Integer = 0
        Dim captureFrameCnt As Int64 = 0
        Dim currCaptureIdx As Int64 = 0
        Dim oldIndex As Long = 0
        Dim imageDataSize As Long = 0
        Dim frameCnt As Long = SampleAplDef.D_OTHERMODE_FRAME_COUNT
        Dim dataTrasmit As Long = SampleAplDef.D_DATA_TRANSMIT_COUNT
        Dim dataCount As Long = SampleAplDef.D_DATA_COUNT_MAX_VALUE
        Dim sizeX As Int64 = 0
        Dim sizeY As Int64 = 0
        Dim gainMode As Long = CLng(E_GAINMODE.D_GAINMODE_SENSOR)
        Dim sensorGainMode As Long = CLng(E_SENSORGAINMODE.D_SENSORGAINMODE_LOWGAIN)
        Dim imageData As UShort() = Nothing
        Dim imageHeader As UShort() = Nothing
        Dim time As UInt64() = Nothing

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        Console.WriteLine("Parameter setting.........")

        'Set CaptureMode 
        lReturn = objWrrUSB.USB2_setCaptureMode(m_lDeviceID, CLng(E_CAPTUREMODE.D_CAPTUREMODE_CONTINUOUS))
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setCaptureMode failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        ' Set TriggerMode
        lReturn = objWrrUSB.USB2_setTriggerMode(m_lDeviceID, CLng(E_TRIGGERMODE.D_TRIGGERMODE_INTERNAL))
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setTriggerMode failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set acquired data count
        lReturn = objWrrUSB.USB2_setDataCount(m_lDeviceID, dataCount)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setDataCount failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set data transmit count
        lReturn = objWrrUSB.USB2_setDataTransmit(m_lDeviceID, dataTrasmit)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setDataTransmit failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set exposure cycle
        lReturn = objWrrUSB.USB2_setExposureCycle(m_lDeviceID, SampleAplDef.D_CYCLE_TIME)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setExposureCycle failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set exposure time
        lReturn = objWrrUSB.USB2_setExposureTime(m_lDeviceID, SampleAplDef.D_EXPOSURE_TIME)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setExposureTime failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set gain value(Set the sensor gain mode, and set low gain or high gain)
        lReturn = objWrrUSB.USB2_setGain(m_lDeviceID, gainMode, sensorGainMode)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setGain failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Get image size
        lReturn = objWrrUSB.USB2_getImageSize(m_lDeviceID, sizeX, sizeY)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_getImageSize failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If
        pixelSize = sizeX * sizeY

        Console.WriteLine("Allocate buffer.........")

        'Buffer allocation
        lReturn = objWrrUSB.USB2_allocateBuffer(m_lDeviceID, frameCnt)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_allocateBuffer failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Capture start
        Console.WriteLine("Start Capture.............")
        lReturn = objWrrUSB.USB2_captureStart(m_lDeviceID, frameCnt)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: Data capture can not be start.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        Console.WriteLine("")
        Console.WriteLine("Image Data ")

        'Data acquisition is reapeated 5 times while determining status of capture
        Do
            'Acquire capture status
            lReturn = objWrrUSB.USB2_getCaptureStatus(m_lDeviceID, captureFrameCnt, currCaptureIdx)
            Trace.WriteLine("APLLOGC++:CaptureStatus lReturn = " & lReturn.ToString() & " captureFrameCnt = " & captureFrameCnt.ToString() & "currCaptureIdx = " & currCaptureIdx.ToString())
            If lReturn = CLng(Usb2Struct.Cusb2Err.usb2Success) Then

                'Calculate old index
                If captureFrameCnt > currCaptureIdx + 1 Then
                    oldIndex = SampleAplDef.D_OTHERMODE_FRAME_COUNT - (captureFrameCnt - (currCaptureIdx + 1))
                Else
                    oldIndex = (currCaptureIdx - captureFrameCnt) + 1
                End If

                'Allocate buffer to store header
                imageHeader = New UShort(SampleAplDef.D_IMAGE_HEADER_SIZE * captureFrameCnt - 1) {}
                If imageHeader Is Nothing Then
                    Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
                End If
                Array.Clear(imageHeader, 0, imageHeader.Length)

                'Allocate a buffer to store data
                imageDataSize = captureFrameCnt * dataTrasmit * pixelSize
                imageData = New UShort(imageDataSize - 1) {}
                If imageData Is Nothing Then
                    Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
                End If
                Array.Clear(imageData, 0, imageData.Length)

                'Allocate buffer to store time
                time = New UInt64(dataTrasmit * captureFrameCnt - 1) {}
                If time Is Nothing Then
                    Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)


                End If

                'Get data from device
                lReturn = objWrrUSB.USB2_getImageHeaderData(m_lDeviceID, imageHeader, imageData, oldIndex, captureFrameCnt, time)
                Trace.WriteLine("APLLOGC++:getImageHeaderData lReturn = " & lReturn.ToString())
                If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
                    objWrrUSB.USB2_captureStop(m_lDeviceID)
                    objWrrUSB.USB2_releaseBuffer(m_lDeviceID)
                    Console.WriteLine("Error code 0x{0:x04}: USB2_getImageHeaderData failed.", lReturn)
                    Console.WriteLine("Exit by pressing the key")
                    Console.ReadKey()
                    Return lReturn
                End If

                'Display data
                DisplayData(imageData)

                'Release allocated buffer
                If imageData IsNot Nothing Then
                    imageData = Nothing
                End If
                If imageHeader IsNot Nothing Then
                    imageHeader = Nothing
                End If
                If time IsNot Nothing Then
                    time = Nothing
                End If

                repeatCount += 1
            End If
            Thread.Sleep(250)
        Loop While repeatCount < SampleAplDef.D_REPEAT_COUNT

        'Stop capture
        Console.WriteLine("Stop Capture.........")
        lReturn = objWrrUSB.USB2_captureStop(m_lDeviceID)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_captureStop failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        Thread.Sleep(100)

        'Release buffer
        Console.WriteLine("Rleasing Buffer......")
        lReturn = objWrrUSB.USB2_releaseBuffer(m_lDeviceID)
        If lReturn <> CType(Usb2Struct.Cusb2Err.usb2Success, Int32) Then
            Console.Write("Error code 0x{0:x04}: USB2_releaseBuffer failed.", lReturn)
            Return lReturn
        End If

        Console.WriteLine("End of measurement")

        Return CLng(Usb2Struct.Cusb2Err.usb2Success)
    End Function

    ''' <summary>
    ''' Measurement start function (Trigger mode)
    ''' </summary>
    ''' <param name="objWrrUSB">DLL</param>
    ''' <returns></returns>
    Private Shared Function StartMeasureForTriggerMode(ByRef objWrrUSB As WRRUSB2) As Long
        Dim lReturn As Long = 0
        Dim pixelSize As Long = 0
        Dim repeatCount As Integer = 0
        Dim captureFrameCnt As Int64 = 0
        Dim currCaptureIdx As Int64 = 0
        Dim oldIndex As Long = 0
        Dim imageDataSize As Long = 0
        Dim frameCnt As Long = SampleAplDef.D_OTHERMODE_FRAME_COUNT
        Dim dataTrasmit As Long = SampleAplDef.D_DATA_TRANSMIT_COUNT
        Dim dataCount As Long = SampleAplDef.D_DATA_COUNT_MAX_VALUE
        Dim sizeX As Int64 = 0
        Dim sizeY As Int64 = 0
        Dim gainMode As Long = CLng(E_GAINMODE.D_GAINMODE_SENSOR)
        Dim sensorGainMode As Long = CLng(E_SENSORGAINMODE.D_SENSORGAINMODE_LOWGAIN)
        Dim imageData As UShort() = Nothing
        Dim imageHeader As UShort() = Nothing
        Dim time As UInt64() = Nothing

        'Argument error check
        If objWrrUSB Is Nothing Then
            Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
        End If

        Console.WriteLine("Parameter setting.........")

        'Set CaptureMode 
        lReturn = objWrrUSB.USB2_setCaptureMode(m_lDeviceID, CLng(E_CAPTUREMODE.D_CAPTUREMODE_TRIGGER))
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setCaptureMode failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        ' Set TriggerMode
        lReturn = objWrrUSB.USB2_setTriggerMode(m_lDeviceID, CLng(E_TRIGGERMODE.D_TRIGGERMODE_SOFTSYNC))
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setTriggerMode failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set acquired data count
        lReturn = objWrrUSB.USB2_setDataCount(m_lDeviceID, dataCount)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setDataCount failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set data transmit count
        lReturn = objWrrUSB.USB2_setDataTransmit(m_lDeviceID, dataTrasmit)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setDataTransmit failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set exposure cycle
        lReturn = objWrrUSB.USB2_setExposureCycle(m_lDeviceID, SampleAplDef.D_CYCLE_TIME)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setExposureCycle failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set exposure time
        lReturn = objWrrUSB.USB2_setExposureTime(m_lDeviceID, SampleAplDef.D_EXPOSURE_TIME)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setExposureTime failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Set gain value(Set the sensor gain mode, and set low gain or high gain)
        lReturn = objWrrUSB.USB2_setGain(m_lDeviceID, gainMode, sensorGainMode)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_setGain failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Get image size
        lReturn = objWrrUSB.USB2_getImageSize(m_lDeviceID, sizeX, sizeY)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_getImageSize failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If
        pixelSize = sizeX * sizeY

        Console.WriteLine("Allocate buffer.........")

        'Buffer allocation
        lReturn = objWrrUSB.USB2_allocateBuffer(m_lDeviceID, frameCnt)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_allocateBuffer failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        'Capture start
        Console.WriteLine("Start Capture.............")
        lReturn = objWrrUSB.USB2_captureStart(m_lDeviceID, frameCnt)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: Data capture can not be start.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        ' Fire trigger
        Console.WriteLine("Fire Trigger.........")
        lReturn = objWrrUSB.USB2_fireTrigger(m_lDeviceID)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_fireTrigger failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        Console.WriteLine("")
        Console.WriteLine("Image Data ")

        'Data acquisition is reapeated 5 times while determining status of capture
        Do
            'Acquire capture status
            lReturn = objWrrUSB.USB2_getCaptureStatus(m_lDeviceID, captureFrameCnt, currCaptureIdx)
            Trace.WriteLine("APLLOGC++:CaptureStatus lReturn = " & lReturn.ToString() & " captureFrameCnt = " & captureFrameCnt.ToString() & "currCaptureIdx = " & currCaptureIdx.ToString())
            If lReturn = CLng(Usb2Struct.Cusb2Err.usb2Success) Then

                'Calculate old index
                If captureFrameCnt > currCaptureIdx + 1 Then
                    oldIndex = SampleAplDef.D_OTHERMODE_FRAME_COUNT - (captureFrameCnt - (currCaptureIdx + 1))
                Else
                    oldIndex = (currCaptureIdx - captureFrameCnt) + 1
                End If

                'Allocate buffer to store header
                imageHeader = New UShort(SampleAplDef.D_IMAGE_HEADER_SIZE * captureFrameCnt - 1) {}
                If imageHeader Is Nothing Then
                    Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
                End If
                Array.Clear(imageHeader, 0, imageHeader.Length)

                'Allocate a buffer to store data
                imageDataSize = captureFrameCnt * dataTrasmit * pixelSize
                imageData = New UShort(imageDataSize - 1) {}
                If imageData Is Nothing Then
                    Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)
                End If
                Array.Clear(imageData, 0, imageData.Length)

                'Allocate buffer to store time
                time = New UInt64(dataTrasmit * captureFrameCnt - 1) {}
                If time Is Nothing Then
                    Return CLng(Usb2Struct.Cusb2Err.usb2Err_unsuccess)


                End If

                'Get data from device
                lReturn = objWrrUSB.USB2_getImageHeaderData(m_lDeviceID, imageHeader, imageData, oldIndex, captureFrameCnt, time)
                Trace.WriteLine("APLLOGC++:getImageHeaderData lReturn = " & lReturn.ToString())
                If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
                    objWrrUSB.USB2_captureStop(m_lDeviceID)
                    objWrrUSB.USB2_releaseBuffer(m_lDeviceID)
                    Console.WriteLine("Error code 0x{0:x04}: USB2_getImageHeaderData failed.", lReturn)
                    Console.WriteLine("Exit by pressing the key")
                    Console.ReadKey()
                    Return lReturn
                End If

                'Display data
                DisplayData(imageData)

                'Release allocated buffer
                If imageData IsNot Nothing Then
                    imageData = Nothing
                End If
                If imageHeader IsNot Nothing Then
                    imageHeader = Nothing
                End If
                If time IsNot Nothing Then
                    time = Nothing
                End If

                repeatCount += 1

                If repeatCount < SampleAplDef.D_REPEAT_COUNT Then
                    ' Fire trigger
                    Console.WriteLine("Fire Trigger.........")
                    lReturn = objWrrUSB.USB2_fireTrigger(m_lDeviceID)
                    If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
                        Console.WriteLine("Error code 0x{0:x04}: USB2_fireTrigger failed.", lReturn)
                        Console.WriteLine("Exit by pressing the key")
                        Console.ReadKey()
                        Return lReturn
                    End If
                End If
            End If
            Thread.Sleep(250)
        Loop While repeatCount < SampleAplDef.D_REPEAT_COUNT

        'Stop capture
        Console.WriteLine("Stop Capture.........")
        lReturn = objWrrUSB.USB2_captureStop(m_lDeviceID)
        If lReturn <> CLng(Usb2Struct.Cusb2Err.usb2Success) Then
            Console.WriteLine("Error code 0x{0:x04}: USB2_captureStop failed.", lReturn)
            Console.WriteLine("Exit by pressing the key")
            Console.ReadKey()
            Return lReturn
        End If

        Thread.Sleep(100)

        'Release buffer
        Console.WriteLine("Rleasing Buffer......")
        lReturn = objWrrUSB.USB2_releaseBuffer(m_lDeviceID)
        If lReturn <> CType(Usb2Struct.Cusb2Err.usb2Success, Int32) Then
            Console.Write("Error code 0x{0:x04}: USB2_releaseBuffer failed.", lReturn)
            Return lReturn
        End If

        Console.WriteLine("End of measurement")

        Return CLng(Usb2Struct.Cusb2Err.usb2Success)
    End Function

    ''' <summary>
    ''' Display data function
    ''' </summary>
    ''' <param name="imageData">Data</param>
    ''' <returns></returns>
    Private Shared Function DisplayData(imageData As UShort()) As Boolean
        Dim dispData As String = String.Empty
        Dim data As Integer = 0
        'Output data to the console
        For nIdx As Integer = 0 To imageData.Length - 1
            data = imageData(nIdx)
            dispData = String.Format("{0:X04} ", data)
            Console.Write(dispData)
            dispData = ""
        Next
        Console.WriteLine("")
        Return True
    End Function
End Class
