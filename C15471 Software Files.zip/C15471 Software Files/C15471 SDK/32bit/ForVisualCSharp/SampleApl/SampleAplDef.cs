using System;
using System.Collections.Generic;
using System.Text;

namespace SampleApl
{
    class SampleAplDef
    {
        public const int D_IMAGE_HEADER_SIZE = 256;		//Header size
        public const int D_DATA_COUNT_MAX_VALUE = 1;		//Data count
        public const int D_DATA_TRANSMIT_COUNT = 1;		//Data transmit count
        public const int D_FREQUENCYMODE_FRAME_COUNT = 1;		//Frame count(Frequency specified mode)
        public const int D_OTHERMODE_FRAME_COUNT = 5;		//Frame count(Capture mode continuous and trigger)
        public const int D_EXPOSURE_TIME = 20000;	//Exposure Time(usec)
        public const int D_CYCLE_TIME = 210000;	//Cycle time(usec)
        public const int D_REPEAT_COUNT = 5;		//Repeat count
    }

    //-----------------------------------------------------------------------------
    // enum
    //-----------------------------------------------------------------------------
    enum E_CAPTUREMODE
    {					        //Capture mode
        D_CAPTUREMODE_COUNT = 0x00000000,	//Frequency specified meausrement mode
        D_CAPTUREMODE_CONTINUOUS = 0x00000001,	//Continous measurement mode
        D_CAPTUREMODE_TRIGGER = 0x00000002,	//Trigger mode
    }

    enum E_TRIGGERMODE
    {
        D_TRIGGERMODE_INTERNAL = 0x00000000,		//Internal synchronous mode
        D_TRIGGERMODE_SOFTASYNC = 0x00000001,		//Software asynchronous mode
        D_TRIGGERMODE_SOFTSYNC = 0x00000002,		//Software synchronous mode
        D_TRIGGERMODE_EXTASYNCEDGE = 0x00000003,		//External asynchronous edge sense mode
        D_TRIGGERMODE_EXTASYNCLEVEL = 0x00000004,		//External asynchronous level sense mode
        D_TRIGGERMODE_EXTSYNCEDGE = 0x00000005,		//External synchronous edge sense mode
        D_TRIGGERMODE_EXTSYNCLEVEL = 0x00000006,		//External synchronous level sense mode
        D_TRIGGERMODE_EXTSYNCPULSE = 0x00000007,		//External synchronous pulse mode
    }

    enum E_CALIBRATIONCOEFFICIENT
    {
        D_CALIBRATIONCOEFFICIENT_WAVELENGTH = 0x00000000,		//Wavelength calibration coefficient
        D_CALIBRATIONCOEFFICIENT_SENSIBILITY = 0x00000001,		//Sensibility calibration coefficient
    }

    enum E_GAINMODE
    {
        D_GAINMODE_SENSOR = 0x00000000,		//SensorGainMode
        D_GAINMODE_CIRCUIT = 0x00000001,		//CircuitGainMode
    };

    enum E_SENSORGAINMODE
    {
        D_SENSORGAINMODE_LOWGAIN = 0x00000000,	//Low Gain
        D_SENSORGAINMODE_HIGHGAIN = 0x00000001,	//High Gain
        D_SENSORGAINMODE_NOTHING = 0x000000FF,	//Nothing
    }
}
