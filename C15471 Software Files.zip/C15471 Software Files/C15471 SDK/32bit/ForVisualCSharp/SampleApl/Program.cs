﻿// ======================================================================================
//
//  Copyright (c) 2019 Hamamatsu Photonics K.K.
//
//  Project         : C15471 Sample Application(C#)
//
//  .NET Framework  : .NET Framework 3.5
//
//=======================================================================================
using System;
using System.Threading;
using System.Diagnostics;
using WRRUSB2_DLL;

namespace SampleApl
{
    /// <summary>
    /// Program class
    /// </summary>
    class Program
    {
        /// <summary>
        /// Device ID
        /// </summary>
        private static long m_lDeviceID = -1;

        /// <summary>
        /// Main
        /// </summary>
        /// <param name="args"></param>
        private static void Main(string[] args)
        {
            long lReturn = 0;
            int nLoopFlag = 1;
            char cInput = ' ';
            WRRUSB2 objWrrUSB = null;

            Console.WriteLine("Hamamatsu Minispectrometer sample application");

            //Create object of WRRUSB2 class
            objWrrUSB = new WRRUSB2();
            if (objWrrUSB == null)
            {
                return;
            }

            //Device initialize
            lReturn = InitializeDevice(ref objWrrUSB);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                return;
            }

            //print the menu
            PrintMenu();
            while (nLoopFlag == 1)
            {
                Console.Write(">");
                cInput = char.ToUpper(Console.ReadKey().KeyChar);
                Console.WriteLine("");

                switch (cInput)
                {
                    case '0':
                        PrintMenu();
                        break;

                    case '1':
                        lReturn = GetDeivceInformation(ref objWrrUSB);
                        break;

                    case '2':
                        lReturn = GetCalibrationValue(ref objWrrUSB);
                        break;

                    case '3':
                        lReturn = GetLDPower(ref objWrrUSB);
                        break;

                    case '4':
                        lReturn = SetLDPower(ref objWrrUSB);
                        break;

                    case '5':
                        lReturn = GetLDPowerEnable(ref objWrrUSB);
                        break;

                    case '6':
                        lReturn = SetLDPowerEnable(ref objWrrUSB);
                        break;

                    case '7':
                        lReturn = GetLDTemperature(ref objWrrUSB);
                        break;

                    case '8':
                        lReturn = GetLDBoardTemperature(ref objWrrUSB);
                        break;

                    case 'F':
                        lReturn = StartMeasureForFrequencyMode(ref objWrrUSB);
                        break;

                    case 'G':
                        lReturn = StartMeasureForContinuousMode(ref objWrrUSB);
                        break;

                    case 'H':
                        lReturn = StartMeasureForTriggerMode(ref objWrrUSB);
                        break;

                    case 'Q':
                        nLoopFlag = 0;
                        break;

                    default:
                        break;
                }
            }

            //Device uninitialize
            lReturn = UninitializeDevice(ref objWrrUSB);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                return;
            }

            return;
        }

        /// <summary>
        /// Initialize device function
        /// </summary>
        /// <param name="objWrrUSB">DLL</param>
        /// <returns></returns>
        private static long InitializeDevice(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;
            ushort strNum = 0;
            short[] arysDeviceList = null;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            //Initialization
            lReturn = objWrrUSB.USB2_initialize();
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: Dll Can not be Initialized.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Device ID storage area allocation
            arysDeviceList = new short[8];
            if (arysDeviceList == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }
            Array.Clear(arysDeviceList, 0, arysDeviceList.Length);

            //Get connected device list
            lReturn = objWrrUSB.USB2_getModuleConnectionList(arysDeviceList, ref strNum);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                objWrrUSB.USB2_uninitialize();
                Console.WriteLine("Error code 0x{0:x04}: Module Connection list failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set acquired device ID
            m_lDeviceID = arysDeviceList[0];

            //Open device
            lReturn = objWrrUSB.USB2_open(m_lDeviceID);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                objWrrUSB.USB2_uninitialize();
                Console.WriteLine("Error code 0x{0:x04}: Device can not be open.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            return lReturn;
        }

        /// <summary>
        /// Uninitialize device function
        /// </summary>
        /// <param name="objWrrUSB">DLL</param>
        /// <returns></returns>
        private static long UninitializeDevice(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            //Close device
            lReturn = objWrrUSB.USB2_close(m_lDeviceID);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: Device can not be closed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Uninitialization
            lReturn = objWrrUSB.USB2_uninitialize();
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_uninitialize failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
            }

            return lReturn;
        }

        /// <summary>
        /// Get device information function
        /// </summary>
        /// <param name="objWrrUSB">DLL</param>
        /// <returns></returns>
        private static long GetDeivceInformation(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;
            Usb2Struct.CModuleInformation objModuleInfo = null;
            Usb2Struct.CSpectroInformation objSpecInfo = null;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            try
            {
                objModuleInfo = new Usb2Struct.CModuleInformation();
                objSpecInfo = new Usb2Struct.CSpectroInformation();
            }
            catch (OutOfMemoryException)
            {
                Debug.Assert(false);
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            lReturn = objWrrUSB.USB2_getModuleInformation(m_lDeviceID, ref objModuleInfo);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_getModuleInformation failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
            }

            lReturn = objWrrUSB.USB2_getSpectroInformation(m_lDeviceID, ref objSpecInfo);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_getSpectroInformation failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
            }

            Console.WriteLine("Deivce information");
            Console.WriteLine("ModelName : {0}", objModuleInfo.product);
            Console.WriteLine("SerialNo  : {0}", objModuleInfo.serial);
            Console.WriteLine("UnitID    : {0}", objSpecInfo.unit);
            Console.WriteLine("FirmVer   : {0}", objModuleInfo.firmware);

            return lReturn;
        }

        /// <summary>
        /// Get calibration value function
        /// </summary>
        /// <param name="objWrrUSB">DLL</param>
        /// <returns></returns>
        private static long GetCalibrationValue(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;
            double[] arydblCalibration = null;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            try
            {
                arydblCalibration = new double[6];
            }
            catch (OutOfMemoryException)
            {
                Debug.Assert(false);
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            lReturn = objWrrUSB.USB2_getCalibrationCoefficient(m_lDeviceID, (long)E_CALIBRATIONCOEFFICIENT.D_CALIBRATIONCOEFFICIENT_WAVELENGTH, arydblCalibration);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_getCalibrationCoefficient failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            Console.WriteLine("Calibration coefficients");
            Console.WriteLine("  A0 : {0:E}", arydblCalibration[0]);
            Console.WriteLine("  B1 : {0:E}", arydblCalibration[1]);
            Console.WriteLine("  B2 : {0:E}", arydblCalibration[2]);
            Console.WriteLine("  B3 : {0:E}", arydblCalibration[3]);
            Console.WriteLine("  B4 : {0:E}", arydblCalibration[4]);
            Console.WriteLine("  B5 : {0:E}", arydblCalibration[5]);
            Console.WriteLine("");

            return lReturn;
        }

        /// <summary>
        /// Get LD Power
        /// </summary>
        /// <param name="objWrrUSB">DLL</param>
        /// <returns></returns>
        private static long GetLDPower(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;
            long lLDPower = 0;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            lReturn = objWrrUSB.USB2_getLDPower(m_lDeviceID, ref lLDPower);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_getLDPower failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }
            Console.WriteLine("LD Power : 0x{0:X08}", lLDPower);
            Console.WriteLine("");

            return lReturn;
        }

        /// <summary>
        /// Set LD Power
        /// </summary>
        /// <param name="objWrrUSB">DLL</param>
        /// <returns></returns>
        private static long SetLDPower(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;
            long lLDPower = 0;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            Console.WriteLine("Input LDPower (long)");
            Console.WriteLine("LOW    : 1");
            Console.WriteLine("MIDDLE : 2");
            Console.WriteLine("HIGH   : 3");

            try
            {
                Console.Write("Set LD Power > ");
                long.TryParse(Console.ReadLine(), out lLDPower);
            }
            catch (Exception)
            {
                Debug.Assert(false);
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            lReturn = objWrrUSB.USB2_setLDPower(m_lDeviceID, lLDPower);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setLDPower failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }
            Console.WriteLine("");

            return lReturn;
        }

        /// <summary>
        /// Get LD Power enable
        /// </summary>
        /// <param name="objWrrUSB"></param>
        /// <returns></returns>
        private static long GetLDPowerEnable(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;
            long lLDPowerEnable = 0;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            lReturn = objWrrUSB.USB2_getLDPowerEnable(m_lDeviceID, ref lLDPowerEnable);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_getLDPowerEnable failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }
            Console.WriteLine("LD Power Enable : 0x{0:x08}", lLDPowerEnable);
            Console.WriteLine("");

            return lReturn;
        }

        /// <summary>
        /// Set LD Power enable
        /// </summary>
        /// <param name="objWrrUSB"></param>
        /// <returns></returns>
        private static long SetLDPowerEnable(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;
            long lLDPowerEnable = 0;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            try
            {
                Console.WriteLine("Input LDPowerEnable (long)");
                Console.WriteLine("Enable  : 1");
                Console.WriteLine("Disable : Other than 1");
                Console.Write("Set LD Power Enable > ");
                long.TryParse(Console.ReadLine(), out lLDPowerEnable);
            }
            catch (Exception)
            {
                Debug.Assert(false);
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            lReturn = objWrrUSB.USB2_setLDPowerEnable(m_lDeviceID, lLDPowerEnable);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setLDPowerEnable failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }
            Console.WriteLine("");

            return lReturn;
        }

        /// <summary>
        /// Get LD temperature
        /// </summary>
        /// <param name="objWrrUSB"></param>
        /// <returns></returns>
        private static long GetLDTemperature(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;
            long lLDTemp = 0;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            lReturn = objWrrUSB.USB2_getLDTemp(m_lDeviceID, ref lLDTemp);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_getLDTemp failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }
            Console.WriteLine("LDTemp : {0}[degC]", (double)lLDTemp / 100);
            Console.WriteLine("");

            return lReturn;
        }

        /// <summary>
        /// Get LD board temperature
        /// </summary>
        /// <param name="objWrrUSB"></param>
        /// <returns></returns>
        private static long GetLDBoardTemperature(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;
            long lLDBoardTemp = 0;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            lReturn = objWrrUSB.USB2_getLDBoardTemp(m_lDeviceID, ref lLDBoardTemp);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_getLDBoardTemp failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }
            Console.WriteLine("LDBoardTemp : {0}[degC]", (double)lLDBoardTemp / 100);
            Console.WriteLine("");

            return lReturn;
        }

        /// <summary>
        /// Display manu function
        /// </summary>
        private static void PrintMenu()
        {
            Console.WriteLine("--------------------------------------------------------------------------");
            Console.WriteLine("  Menu               (0) Menu");
            Console.WriteLine("  DeviceInformation  (1) Get");
            Console.WriteLine("  Calibration        (2) Get");
            Console.WriteLine("  LDPower            (3) Get            (4) Set");
            Console.WriteLine("  LDPowerEnable      (5) Get            (6) Set");
            Console.WriteLine("  LDTemperature      (7) Get");
            Console.WriteLine("  LDBoardTemp        (8) Get");
            Console.WriteLine("  Measure            (F) FrequencyMode  (G) ContinuousMode (H) TriggerMode");
            Console.WriteLine("  Quit               (Q) Quit");
            Console.WriteLine("--------------------------------------------------------------------------");
        }

        /// <summary>
        /// Measurement start function (Frequency specified meausrement mode)
        /// </summary>
        /// <param name="objWrrUSB">DLL</param>
        /// <returns></returns>
        private static long StartMeasureForFrequencyMode(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;
            long pixelSize = 0;
            int repeatCount = 0;
            Int64 captureFrameCnt = 0;
            Int64 currCaptureIdx = 0;
            long oldIndex = 0;
            long imageDataSize = 0;
            long frameCnt = SampleAplDef.D_FREQUENCYMODE_FRAME_COUNT;
            long dataTrasmit = SampleAplDef.D_DATA_TRANSMIT_COUNT;
            long dataCount = SampleAplDef.D_DATA_COUNT_MAX_VALUE;
            Int64 sizeX = 0;
            Int64 sizeY = 0;
            long gainMode = (long)E_GAINMODE.D_GAINMODE_SENSOR;
            long sensorGainMode = (long)E_SENSORGAINMODE.D_SENSORGAINMODE_LOWGAIN;
            ushort[] imageData = null;
            ushort[] imageHeader = null;
            UInt64[] time = null;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            Console.WriteLine("Parameter setting.........");

            //Set CaptureMode 
            lReturn = objWrrUSB.USB2_setCaptureMode(m_lDeviceID, (long)E_CAPTUREMODE.D_CAPTUREMODE_COUNT);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setCaptureMode failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            // Set TriggerMode
            lReturn = objWrrUSB.USB2_setTriggerMode(m_lDeviceID, (long)E_TRIGGERMODE.D_TRIGGERMODE_INTERNAL);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setTriggerMode failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set acquired data count
            lReturn = objWrrUSB.USB2_setDataCount(m_lDeviceID, dataCount);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setDataCount failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set data transmit count
            lReturn = objWrrUSB.USB2_setDataTransmit(m_lDeviceID, dataTrasmit);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setDataTransmit failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set exposure cycle
            lReturn = objWrrUSB.USB2_setExposureCycle(m_lDeviceID, SampleAplDef.D_CYCLE_TIME);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setExposureCycle failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set exposure time
            lReturn = objWrrUSB.USB2_setExposureTime(m_lDeviceID, SampleAplDef.D_EXPOSURE_TIME);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setExposureTime failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set gain value(Set the sensor gain mode, and set low gain or high gain)
            lReturn = objWrrUSB.USB2_setGain(m_lDeviceID, gainMode, sensorGainMode);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setGain failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Get image size
            lReturn = objWrrUSB.USB2_getImageSize(m_lDeviceID, ref sizeX, ref sizeY);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_getImageSize failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }
            pixelSize = sizeX * sizeY;

            Console.WriteLine("Allocate buffer.........");

            //Buffer allocation
            lReturn = objWrrUSB.USB2_allocateBuffer(m_lDeviceID, frameCnt);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_allocateBuffer failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Capture start
            Console.WriteLine("Start Capture.............");
            lReturn = objWrrUSB.USB2_captureStart(m_lDeviceID, frameCnt);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: Data capture can not be start.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            Console.WriteLine("");
            Console.WriteLine("Image Data ");

            //Data acquisition is reapeated 5 times while determining status of capture
            do
            {
                //Acquire capture status
                lReturn = objWrrUSB.USB2_getCaptureStatus(m_lDeviceID, ref captureFrameCnt, ref currCaptureIdx);
                Trace.WriteLine("APLLOGC++:CaptureStatus lReturn = " + lReturn.ToString() + " captureFrameCnt = " + captureFrameCnt.ToString() + "currCaptureIdx = " + currCaptureIdx.ToString());
                if (lReturn == (long)Usb2Struct.Cusb2Err.usb2Success)
                {

                    //Calculate old index
                    if (captureFrameCnt > currCaptureIdx + 1)
                    {
                        oldIndex = SampleAplDef.D_OTHERMODE_FRAME_COUNT - (captureFrameCnt - (currCaptureIdx + 1));
                    }
                    else
                    {
                        oldIndex = (currCaptureIdx - captureFrameCnt) + 1;
                    }

                    //Allocate buffer to store header
                    imageHeader = new ushort[SampleAplDef.D_IMAGE_HEADER_SIZE * captureFrameCnt];
                    if (imageHeader == null)
                    {
                        return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
                    }
                    Array.Clear(imageHeader, 0, imageHeader.Length);

                    //Allocate a buffer to store data
                    imageDataSize = captureFrameCnt * dataTrasmit * pixelSize;
                    imageData = new ushort[imageDataSize];
                    if (imageData == null)
                    {
                        return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
                    }
                    Array.Clear(imageData, 0, imageData.Length);

                    //Allocate buffer to store time
                    time = new UInt64[dataTrasmit * captureFrameCnt];
                    if (time == null)
                    {
                        return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
                    }

                    //Get data from device
                    lReturn = objWrrUSB.USB2_getImageHeaderData(m_lDeviceID, ref imageHeader, ref imageData, oldIndex, captureFrameCnt, ref time);
                    Trace.WriteLine("APLLOGC++:getImageHeaderData lReturn = " + lReturn.ToString());
                    if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
                    {

                        Console.WriteLine("Error code 0x{0:x04}: USB2_getImageHeaderData failed.", lReturn);
                        Console.WriteLine("Exit by pressing the key");
                        Console.ReadKey();
                        return lReturn;
                    }

                    //Display data
                    DisplayData(imageData);

                    Console.WriteLine("Stop Capture.........");
                    //Stop capture
                    lReturn = objWrrUSB.USB2_captureStop(m_lDeviceID);
                    if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
                    {
                        Console.WriteLine("Error code 0x{0:x04}: USB2_captureStop failed.", lReturn);
                        Console.WriteLine("Exit by pressing the key");
                        Console.ReadKey();
                        return lReturn;
                    }

                    //Release allocated buffer
                    if (imageData != null)
                    {
                        imageData = null;
                    }
                    if (imageHeader != null)
                    {
                        imageHeader = null;
                    }
                    if (time != null)
                    {
                        time = null;
                    }

                    repeatCount++;

                    if (repeatCount < SampleAplDef.D_REPEAT_COUNT)
                    {
                        //next Capture start
                        Console.WriteLine("Start Capture.............");
                        lReturn = objWrrUSB.USB2_captureStart(m_lDeviceID, frameCnt);
                        if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
                        {
                            Console.WriteLine("Error code 0x{0:x04}: Data capture can not be start.", lReturn);
                            Console.WriteLine("Exit by pressing the key");
                            Console.ReadKey();
                            return lReturn;
                        }
                    }
                }
                Thread.Sleep(250);
            } while (repeatCount < SampleAplDef.D_REPEAT_COUNT);

            //Stop capture
            Console.WriteLine("Stop Capture.........");
            lReturn = objWrrUSB.USB2_captureStop(m_lDeviceID);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_captureStop failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            Thread.Sleep(100);

            //Release buffer
            Console.WriteLine("Rleasing Buffer......");
            lReturn = objWrrUSB.USB2_releaseBuffer(m_lDeviceID);
            if (lReturn != (Int32)(Usb2Struct.Cusb2Err.usb2Success))
            {
                Console.Write("Error code 0x{0:x04}: USB2_releaseBuffer failed.", lReturn);
                return lReturn;
            }

            Console.WriteLine("End of measurement");

            return (long)Usb2Struct.Cusb2Err.usb2Success;
        }

        /// <summary>
        /// Measurement start function (Continous measurement mode)
        /// </summary>
        /// <param name="objWrrUSB">DLL</param>
        /// <returns></returns>
        private static long StartMeasureForContinuousMode(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;
            long pixelSize = 0;
            int repeatCount = 0;
            Int64 captureFrameCnt = 0;
            Int64 currCaptureIdx = 0;
            long oldIndex = 0;
            long imageDataSize = 0;
            long frameCnt = SampleAplDef.D_OTHERMODE_FRAME_COUNT;
            long dataTrasmit = SampleAplDef.D_DATA_TRANSMIT_COUNT;
            long dataCount = SampleAplDef.D_DATA_COUNT_MAX_VALUE;
            Int64 sizeX = 0;
            Int64 sizeY = 0;
            long gainMode = (long)E_GAINMODE.D_GAINMODE_SENSOR;
            long sensorGainMode = (long)E_SENSORGAINMODE.D_SENSORGAINMODE_LOWGAIN;
            ushort[] imageData = null;
            ushort[] imageHeader = null;
            UInt64[] time = null;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            Console.WriteLine("Parameter setting.........");

            //Set CaptureMode 
            lReturn = objWrrUSB.USB2_setCaptureMode(m_lDeviceID, (long)E_CAPTUREMODE.D_CAPTUREMODE_CONTINUOUS);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setCaptureMode failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            // Set TriggerMode
            lReturn = objWrrUSB.USB2_setTriggerMode(m_lDeviceID, (long)E_TRIGGERMODE.D_TRIGGERMODE_INTERNAL);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setTriggerMode failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set acquired data count
            lReturn = objWrrUSB.USB2_setDataCount(m_lDeviceID, dataCount);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setDataCount failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set data transmit count
            lReturn = objWrrUSB.USB2_setDataTransmit(m_lDeviceID, dataTrasmit);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setDataTransmit failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set exposure cycle
            lReturn = objWrrUSB.USB2_setExposureCycle(m_lDeviceID, SampleAplDef.D_CYCLE_TIME);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setExposureCycle failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set exposure time
            lReturn = objWrrUSB.USB2_setExposureTime(m_lDeviceID, SampleAplDef.D_EXPOSURE_TIME);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setExposureTime failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set gain value(Set the sensor gain mode, and set low gain or high gain)
            lReturn = objWrrUSB.USB2_setGain(m_lDeviceID, gainMode, sensorGainMode);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setGain failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Get image size
            lReturn = objWrrUSB.USB2_getImageSize(m_lDeviceID, ref sizeX, ref sizeY);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_getImageSize failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }
            pixelSize = sizeX * sizeY;

            Console.WriteLine("Allocate buffer.........");

            //Buffer allocation
            lReturn = objWrrUSB.USB2_allocateBuffer(m_lDeviceID, frameCnt);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_allocateBuffer failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Capture start
            Console.WriteLine("Start Capture.............");
            lReturn = objWrrUSB.USB2_captureStart(m_lDeviceID, frameCnt);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: Data capture can not be start.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            Console.WriteLine("");
            Console.WriteLine("Image Data ");

            //Data acquisition is reapeated 5 times while determining status of capture
            do
            {
                //Acquire capture status
                lReturn = objWrrUSB.USB2_getCaptureStatus(m_lDeviceID, ref captureFrameCnt, ref currCaptureIdx);
                Trace.WriteLine("APLLOGC++:CaptureStatus lReturn = " + lReturn.ToString() + " captureFrameCnt = " + captureFrameCnt.ToString() + "currCaptureIdx = " + currCaptureIdx.ToString());
                if (lReturn == (long)Usb2Struct.Cusb2Err.usb2Success)
                {

                    //Calculate old index
                    if (captureFrameCnt > currCaptureIdx + 1)
                    {
                        oldIndex = SampleAplDef.D_OTHERMODE_FRAME_COUNT - (captureFrameCnt - (currCaptureIdx + 1));
                    }
                    else
                    {
                        oldIndex = (currCaptureIdx - captureFrameCnt) + 1;
                    }

                    //Allocate buffer to store header
                    imageHeader = new ushort[SampleAplDef.D_IMAGE_HEADER_SIZE * captureFrameCnt];
                    if (imageHeader == null)
                    {
                        return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
                    }
                    Array.Clear(imageHeader, 0, imageHeader.Length);

                    //Allocate a buffer to store data
                    imageDataSize = captureFrameCnt * dataTrasmit * pixelSize;
                    imageData = new ushort[imageDataSize];
                    if (imageData == null)
                    {
                        return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
                    }
                    Array.Clear(imageData, 0, imageData.Length);

                    //Allocate buffer to store time
                    time = new UInt64[dataTrasmit * captureFrameCnt];
                    if (time == null)
                    {
                        return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess; ;
                    }

                    //Get data from device
                    lReturn = objWrrUSB.USB2_getImageHeaderData(m_lDeviceID, ref imageHeader, ref imageData, oldIndex, captureFrameCnt, ref time);
                    Trace.WriteLine("APLLOGC++:getImageHeaderData lReturn = " + lReturn.ToString());
                    if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
                    {
                        objWrrUSB.USB2_captureStop(m_lDeviceID);
                        objWrrUSB.USB2_releaseBuffer(m_lDeviceID);
                        Console.WriteLine("Error code 0x{0:x04}: USB2_getImageHeaderData failed.", lReturn);
                        Console.WriteLine("Exit by pressing the key");
                        Console.ReadKey();
                        return lReturn;
                    }

                    //Display data
                    DisplayData(imageData);

                    //Release allocated buffer
                    if (imageData != null)
                    {
                        imageData = null;
                    }
                    if (imageHeader != null)
                    {
                        imageHeader = null;
                    }
                    if (time != null)
                    {
                        time = null;
                    }

                    repeatCount++;
                }
                Thread.Sleep(250);
            } while (repeatCount < SampleAplDef.D_REPEAT_COUNT);

            //Stop capture
            Console.WriteLine("Stop Capture.........");
            lReturn = objWrrUSB.USB2_captureStop(m_lDeviceID);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_captureStop failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            Thread.Sleep(100);

            //Release buffer
            Console.WriteLine("Rleasing Buffer......");
            lReturn = objWrrUSB.USB2_releaseBuffer(m_lDeviceID);
            if (lReturn != (Int32)(Usb2Struct.Cusb2Err.usb2Success))
            {
                Console.Write("Error code 0x{0:x04}: USB2_releaseBuffer failed.", lReturn);
                return lReturn;
            }

            Console.WriteLine("End of measurement");

            return (long)Usb2Struct.Cusb2Err.usb2Success;
        }

        /// <summary>
        /// Measurement start function (Trigger mode)
        /// </summary>
        /// <param name="objWrrUSB">DLL</param>
        /// <returns></returns>
        private static long StartMeasureForTriggerMode(ref WRRUSB2 objWrrUSB)
        {
            long lReturn = 0;
            long pixelSize = 0;
            int repeatCount = 0;
            Int64 captureFrameCnt = 0;
            Int64 currCaptureIdx = 0;
            long oldIndex = 0;
            long imageDataSize = 0;
            long frameCnt = SampleAplDef.D_OTHERMODE_FRAME_COUNT;
            long dataTrasmit = SampleAplDef.D_DATA_TRANSMIT_COUNT;
            long dataCount = SampleAplDef.D_DATA_COUNT_MAX_VALUE;
            Int64 sizeX = 0;
            Int64 sizeY = 0;
            long gainMode = (long)E_GAINMODE.D_GAINMODE_SENSOR;
            long sensorGainMode = (long)E_SENSORGAINMODE.D_SENSORGAINMODE_LOWGAIN;
            ushort[] imageData = null;
            ushort[] imageHeader = null;
            UInt64[] time = null;

            //Argument error check
            if (objWrrUSB == null)
            {
                return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
            }

            Console.WriteLine("Parameter setting.........");

            //Set CaptureMode 
            lReturn = objWrrUSB.USB2_setCaptureMode(m_lDeviceID, (long)E_CAPTUREMODE.D_CAPTUREMODE_TRIGGER);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setCaptureMode failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            // Set TriggerMode
            lReturn = objWrrUSB.USB2_setTriggerMode(m_lDeviceID, (long)E_TRIGGERMODE.D_TRIGGERMODE_SOFTSYNC);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setTriggerMode failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set acquired data count
            lReturn = objWrrUSB.USB2_setDataCount(m_lDeviceID, dataCount);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setDataCount failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set data transmit count
            lReturn = objWrrUSB.USB2_setDataTransmit(m_lDeviceID, dataTrasmit);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setDataTransmit failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set exposure cycle
            lReturn = objWrrUSB.USB2_setExposureCycle(m_lDeviceID, SampleAplDef.D_CYCLE_TIME);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setExposureCycle failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set exposure time
            lReturn = objWrrUSB.USB2_setExposureTime(m_lDeviceID, SampleAplDef.D_EXPOSURE_TIME);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setExposureTime failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Set gain value(Set the sensor gain mode, and set low gain or high gain)
            lReturn = objWrrUSB.USB2_setGain(m_lDeviceID, gainMode, sensorGainMode);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_setGain failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Get image size
            lReturn = objWrrUSB.USB2_getImageSize(m_lDeviceID, ref sizeX, ref sizeY);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_getImageSize failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }
            pixelSize = sizeX * sizeY;

            Console.WriteLine("Allocate buffer.........");

            //Buffer allocation
            lReturn = objWrrUSB.USB2_allocateBuffer(m_lDeviceID, frameCnt);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_allocateBuffer failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            //Capture start
            Console.WriteLine("Start Capture.............");
            lReturn = objWrrUSB.USB2_captureStart(m_lDeviceID, frameCnt);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: Data capture can not be start.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            // Fire trigger
            Console.WriteLine("Fire Trigger.........");
            lReturn = objWrrUSB.USB2_fireTrigger(m_lDeviceID);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_fireTrigger failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            Console.WriteLine("");
            Console.WriteLine("Image Data ");

            //Data acquisition is reapeated 5 times while determining status of capture
            do
            {
                //Acquire capture status
                lReturn = objWrrUSB.USB2_getCaptureStatus(m_lDeviceID, ref captureFrameCnt, ref currCaptureIdx);
                Trace.WriteLine("APLLOGC++:CaptureStatus lReturn = " + lReturn.ToString() + " captureFrameCnt = " + captureFrameCnt.ToString() + "currCaptureIdx = " + currCaptureIdx.ToString());
                if (lReturn == (long)Usb2Struct.Cusb2Err.usb2Success)
                {

                    //Calculate old index
                    if (captureFrameCnt > currCaptureIdx + 1)
                    {
                        oldIndex = SampleAplDef.D_OTHERMODE_FRAME_COUNT - (captureFrameCnt - (currCaptureIdx + 1));
                    }
                    else
                    {
                        oldIndex = (currCaptureIdx - captureFrameCnt) + 1;
                    }

                    //Allocate buffer to store header
                    imageHeader = new ushort[SampleAplDef.D_IMAGE_HEADER_SIZE * captureFrameCnt];
                    if (imageHeader == null)
                    {
                        return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
                    }
                    Array.Clear(imageHeader, 0, imageHeader.Length);

                    //Allocate a buffer to store data
                    imageDataSize = captureFrameCnt * dataTrasmit * pixelSize;
                    imageData = new ushort[imageDataSize];
                    if (imageData == null)
                    {
                        return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess;
                    }
                    Array.Clear(imageData, 0, imageData.Length);

                    //Allocate buffer to store time
                    time = new UInt64[dataTrasmit * captureFrameCnt];
                    if (time == null)
                    {
                        return (long)Usb2Struct.Cusb2Err.usb2Err_unsuccess; ;
                    }

                    //Get data from device
                    lReturn = objWrrUSB.USB2_getImageHeaderData(m_lDeviceID, ref imageHeader, ref imageData, oldIndex, captureFrameCnt, ref time);
                    Trace.WriteLine("APLLOGC++:getImageHeaderData lReturn = " + lReturn.ToString());
                    if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
                    {
                        objWrrUSB.USB2_captureStop(m_lDeviceID);
                        objWrrUSB.USB2_releaseBuffer(m_lDeviceID);
                        Console.WriteLine("Error code 0x{0:x04}: USB2_getImageHeaderData failed.", lReturn);
                        Console.WriteLine("Exit by pressing the key");
                        Console.ReadKey();
                        return lReturn;
                    }

                    //Display data
                    DisplayData(imageData);

                    //Release allocated buffer
                    if (imageData != null)
                    {
                        imageData = null;
                    }
                    if (imageHeader != null)
                    {
                        imageHeader = null;
                    }
                    if (time != null)
                    {
                        time = null;
                    }

                    repeatCount++;

                    if (repeatCount < SampleAplDef.D_REPEAT_COUNT)
                    {
                        // Fire trigger
                        Console.WriteLine("Fire Trigger.........");
                        lReturn = objWrrUSB.USB2_fireTrigger(m_lDeviceID);
                        if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
                        {
                            Console.WriteLine("Error code 0x{0:x04}: USB2_fireTrigger failed.", lReturn);
                            Console.WriteLine("Exit by pressing the key");
                            Console.ReadKey();
                            return lReturn;
                        }
                    }
                }
                Thread.Sleep(250);
            } while (repeatCount < SampleAplDef.D_REPEAT_COUNT);

            //Stop capture
            Console.WriteLine("Stop Capture.........");
            lReturn = objWrrUSB.USB2_captureStop(m_lDeviceID);
            if (lReturn != (long)Usb2Struct.Cusb2Err.usb2Success)
            {
                Console.WriteLine("Error code 0x{0:x04}: USB2_captureStop failed.", lReturn);
                Console.WriteLine("Exit by pressing the key");
                Console.ReadKey();
                return lReturn;
            }

            Thread.Sleep(100);

            //Release buffer
            Console.WriteLine("Rleasing Buffer......");
            lReturn = objWrrUSB.USB2_releaseBuffer(m_lDeviceID);
            if (lReturn != (Int32)(Usb2Struct.Cusb2Err.usb2Success))
            {
                Console.Write("Error code 0x{0:x04}: USB2_releaseBuffer failed.", lReturn);
                return lReturn;
            }

            Console.WriteLine("End of measurement");

            return (long)Usb2Struct.Cusb2Err.usb2Success;
        }

        /// <summary>
        /// Display data function
        /// </summary>
        /// <param name="imageData">Data</param>
        /// <returns></returns>
        private static bool DisplayData(ushort[] imageData)
        {
            string dispData = string.Empty;
            int data = 0;
            //Output data to the console
            for (int nIdx = 0; nIdx < imageData.Length; nIdx++)
            {
                data = imageData[nIdx];
                dispData = string.Format("{0:X04} ", data);
                Console.Write(dispData);
                dispData = "";
            }
            Console.WriteLine("");
            return true;
        }
    }
}
