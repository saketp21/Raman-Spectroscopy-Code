// CaptureManager.h
#pragma once

using namespace System;
using namespace System::Collections::Generic;

ref class CaptureManager {
private:
    List<array<unsigned short>^>^ captures;

    // Private constructor to prevent external instantiation.
    CaptureManager() {
        captures = gcnew List<array<unsigned short>^>();
    }

public:
    static property CaptureManager^ Instance {
        CaptureManager^ get() {
            // Local static variable to hold the instance
            static CaptureManager^ instance = gcnew CaptureManager();
            return instance;
        }
    }

    void AddCapture(array<unsigned short>^ data) {
        captures->Add(data);
    }

    array<unsigned short>^ GetCapture(int index) {
        if (index < 0 || index >= captures->Count) {
            throw gcnew ArgumentOutOfRangeException("index");
        }
        return captures[index];
    }

    int GetCount() {
        return captures->Count;
    }
};
