#include "stdafx.h"
#include "GlobalData.h"


std::atomic<bool> capturing(false);
