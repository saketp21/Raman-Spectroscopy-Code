// CaptureManager.cpp
#include "CaptureManager.h"

CaptureManager^ CaptureManager::instance;

CaptureManager::CaptureManager() {
    this->captures = gcnew List<array<unsigned short>^>();
}

CaptureManager^ CaptureManager::Instance::get() {
    if (instance == nullptr) {
        instance = gcnew CaptureManager();
    }
    return instance;
}

void CaptureManager::AddCapture(array<unsigned short>^ data) {
    this->captures->Add(data);
}

array<unsigned short>^ CaptureManager::GetCapture(int index) {
    if (index < 0 || index >= this->captures->Count) {
        throw gcnew ArgumentOutOfRangeException("index", "Index out of range.");
    }
    return this->captures[index];
}
